Optional offline installers:
- Place Node.js LTS installer MSI as: node-lts.msi
- Place XAMPP installer EXE as: xampp-installer.exe

If these files are present, setup uses them first.
If not present, setup tries winget, then opens official download pages.
