
 A web based POS system for grocery stores. The system can be used online and offline to cater for remote areas with low internet / unstable internet connection.
 

