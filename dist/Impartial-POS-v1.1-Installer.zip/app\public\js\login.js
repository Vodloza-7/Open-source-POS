const LoginModule = {
  getDeviceName() {
    const platform = navigator.userAgentData?.platform || navigator.platform || 'Unknown Platform';
    const lang = navigator.language || 'en';
    return `${platform} (${lang})`;
  },

  async init() {
    const loginForm = document.getElementById('loginForm');
    const loginError = document.getElementById('loginError');
    const loginStatus = document.getElementById('loginStatus');

    if (!loginForm) return;

    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      const username = document.getElementById('username').value;
      const password = document.getElementById('password').value;

      loginStatus.textContent = 'Logging in...';
      loginStatus.className = 'login-status loading';

      try {
        const user = await API.login(username, password, {
          deviceName: this.getDeviceName(),
          userAgent: navigator.userAgent || ''
        });
        Auth.setUser(user);
        loginError.textContent = '';
        loginStatus.textContent = 'Login successful!  Welcome to our POS system.';
        loginStatus.className = 'login-status success';

        setTimeout(() => {
          Router.navigate('pos');
        }, 500);
      } catch (error) {
        console.error('Login error:', error);
        loginError.textContent = error.message || 'Login failed. Check your credentials.';
        loginStatus.textContent = '';
        loginStatus.className = '';
      }
    });
  }
};
